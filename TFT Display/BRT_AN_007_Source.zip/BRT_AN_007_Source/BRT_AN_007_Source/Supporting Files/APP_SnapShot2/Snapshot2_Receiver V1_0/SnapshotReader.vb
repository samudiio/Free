Imports System
Imports System.IO
Imports System.Text

Public Class Snapshot
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button_Init As System.Windows.Forms.Button
    Friend WithEvents Button_Run As System.Windows.Forms.Button
    Friend WithEvents Button_Exit As System.Windows.Forms.Button
    Friend WithEvents Label_DevStatus As System.Windows.Forms.Label
    Friend WithEvents Label_NumFtdiDevices As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Button_Save As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label_BytesRead As System.Windows.Forms.Label
    Friend WithEvents Button_Stop As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label_BaudRate As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Snapshot))
        Me.Label36 = New System.Windows.Forms.Label()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label_DevStatus = New System.Windows.Forms.Label()
        Me.Label_NumFtdiDevices = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button_Init = New System.Windows.Forms.Button()
        Me.Button_Run = New System.Windows.Forms.Button()
        Me.Button_Exit = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Button_Save = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label_BytesRead = New System.Windows.Forms.Label()
        Me.Button_Stop = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label_BaudRate = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label36.Location = New System.Drawing.Point(598, 451)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(10, 13)
        Me.Label36.TabIndex = 37
        Me.Label36.Text = "-"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(6, 53)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(77, 13)
        Me.Label25.TabIndex = 32
        Me.Label25.Text = "Device Status:"
        '
        'Label_DevStatus
        '
        Me.Label_DevStatus.AutoSize = True
        Me.Label_DevStatus.Location = New System.Drawing.Point(95, 53)
        Me.Label_DevStatus.Name = "Label_DevStatus"
        Me.Label_DevStatus.Size = New System.Drawing.Size(10, 13)
        Me.Label_DevStatus.TabIndex = 57
        Me.Label_DevStatus.Text = "-"
        Me.Label_DevStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label_NumFtdiDevices
        '
        Me.Label_NumFtdiDevices.AutoSize = True
        Me.Label_NumFtdiDevices.Location = New System.Drawing.Point(95, 28)
        Me.Label_NumFtdiDevices.Name = "Label_NumFtdiDevices"
        Me.Label_NumFtdiDevices.Size = New System.Drawing.Size(10, 13)
        Me.Label_NumFtdiDevices.TabIndex = 55
        Me.Label_NumFtdiDevices.Text = "-"
        Me.Label_NumFtdiDevices.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(6, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 19)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "FTDI Devices:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Button_Init
        '
        Me.Button_Init.Location = New System.Drawing.Point(282, 21)
        Me.Button_Init.Name = "Button_Init"
        Me.Button_Init.Size = New System.Drawing.Size(90, 30)
        Me.Button_Init.TabIndex = 64
        Me.Button_Init.Text = "Initialise"
        Me.Button_Init.UseVisualStyleBackColor = True
        '
        'Button_Run
        '
        Me.Button_Run.Location = New System.Drawing.Point(282, 57)
        Me.Button_Run.Name = "Button_Run"
        Me.Button_Run.Size = New System.Drawing.Size(90, 30)
        Me.Button_Run.TabIndex = 65
        Me.Button_Run.Text = "Run"
        '
        'Button_Exit
        '
        Me.Button_Exit.Location = New System.Drawing.Point(282, 165)
        Me.Button_Exit.Name = "Button_Exit"
        Me.Button_Exit.Size = New System.Drawing.Size(90, 30)
        Me.Button_Exit.TabIndex = 67
        Me.Button_Exit.Text = "Exit"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Label3.Location = New System.Drawing.Point(261, 214)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 13)
        Me.Label3.TabIndex = 69
        Me.Label3.Text = "Version: 1.0"
        '
        'Button_Save
        '
        Me.Button_Save.Location = New System.Drawing.Point(282, 129)
        Me.Button_Save.Name = "Button_Save"
        Me.Button_Save.Size = New System.Drawing.Size(90, 30)
        Me.Button_Save.TabIndex = 70
        Me.Button_Save.Text = "Save Image"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 81)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(62, 13)
        Me.Label4.TabIndex = 72
        Me.Label4.Text = "BytesRead:"
        '
        'Label_BytesRead
        '
        Me.Label_BytesRead.AutoSize = True
        Me.Label_BytesRead.Location = New System.Drawing.Point(95, 81)
        Me.Label_BytesRead.Name = "Label_BytesRead"
        Me.Label_BytesRead.Size = New System.Drawing.Size(10, 13)
        Me.Label_BytesRead.TabIndex = 73
        Me.Label_BytesRead.Text = "-"
        Me.Label_BytesRead.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Button_Stop
        '
        Me.Button_Stop.Location = New System.Drawing.Point(282, 93)
        Me.Button_Stop.Name = "Button_Stop"
        Me.Button_Stop.Size = New System.Drawing.Size(90, 30)
        Me.Button_Stop.TabIndex = 74
        Me.Button_Stop.Text = "Stop"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(6, 108)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(35, 13)
        Me.Label6.TabIndex = 75
        Me.Label6.Text = "Baud:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label_BaudRate)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label_BytesRead)
        Me.GroupBox1.Controls.Add(Me.Label_NumFtdiDevices)
        Me.GroupBox1.Controls.Add(Me.Label25)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label_DevStatus)
        Me.GroupBox1.Location = New System.Drawing.Point(15, 21)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(261, 174)
        Me.GroupBox1.TabIndex = 76
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Status"
        '
        'Label_BaudRate
        '
        Me.Label_BaudRate.AutoSize = True
        Me.Label_BaudRate.Location = New System.Drawing.Point(95, 108)
        Me.Label_BaudRate.Name = "Label_BaudRate"
        Me.Label_BaudRate.Size = New System.Drawing.Size(10, 13)
        Me.Label_BaudRate.TabIndex = 76
        Me.Label_BaudRate.Text = "-"
        Me.Label_BaudRate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Snapshot
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(384, 236)
        Me.ControlBox = False
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Button_Stop)
        Me.Controls.Add(Me.Button_Save)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Button_Exit)
        Me.Controls.Add(Me.Button_Run)
        Me.Controls.Add(Me.Button_Init)
        Me.Controls.Add(Me.Label36)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(400, 270)
        Me.MinimumSize = New System.Drawing.Size(400, 270)
        Me.Name = "Snapshot"
        Me.RightToLeftLayout = True
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.Text = "FT81x Snapshot2 Reader"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

    ' NOTE:   This code is provided as an example only and is not supported or guaranteed by FTDI. The designer of the final application
    ' incorporating any of this sample code is responsible for ensuring it's safe and correct operation. By using this example, the designer 
    ' of the final application/system agrees to accept full responsibiliy for any consequences resulting from its use. Use of FTDI devices 
    ' in life support and/or safety applications is entirely at the user�s risk, and the user agrees to defend, indemnify and hold FTDI 
    ' harmless from any and all damages, claims, suits or expense resulting from such use.

    ' Copyright (C) Future Technology Devices International

    ' Revision History:
    ' Version   Author      Date            Comments
    ' ********* *********** *************** ****************************************************
    ' v1.0      G Brown     Feb 2017        Initial release
    '
    '



    Dim DriverInstalled As Boolean = False
    Dim DeviceInit As Boolean
    Dim filepath As String
    Dim Running As Boolean
    Dim SendBuffer(0 To 65535) As Byte
    Dim NumBytesSent As Integer
    Dim ReceiveBuffer1(0 To 1000000) As Byte
    Dim ClearBuffer(0 To 65535) As Byte
    Dim NumBytesInQueue As Integer
    Dim NumBytesRead As Integer
    Dim Buffer1Index As Double
    Dim Baudrate As Integer


    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' When the application window loads initially

        Dim myProcess As System.Diagnostics.Process = _
        System.Diagnostics.Process.GetCurrentProcess()
        myProcess.PriorityClass = System.Diagnostics.ProcessPriorityClass.High

        ' ######## Initialise the controls on the screen ########

        Label_NumFtdiDevices.Text = " "
        Label_DevStatus.Text = " "

        Button_Init.Enabled = True
        Button_Run.Enabled = False
        Button_Stop.Enabled = False
        Button_Save.Enabled = False
        Button_Exit.Enabled = True
        Button_Init.Focus()

        ' ######## Initialise the variables ########

        DriverInstalled = True
        DeviceInit = False

        ' ######## Update the window ########

        Update()
        Application.DoEvents()

    End Sub


    Private Sub Button_Init_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Init.Click
        ' When user clicks Init button

        Dim DeviceCount As Integer

        ' ######## Prevent user clicking any buttons on user interface until Init complete ########

        Button_Init.Enabled = False
        Button_Run.Enabled = False
        Button_Stop.Enabled = False
        Button_Save.Enabled = False
        Button_Exit.Enabled = False
        Button_Init.Focus()

        ' ######## Check if the driver is installed by accessing a driver function in a try-catch ########

        Try
            FT_Status = FT_GetNumberOfDevices(DeviceCount, vbNullChar, FT_LIST_NUMBER_ONLY)
        Catch ex As Exception
            DriverInstalled = False
        End Try

        If (DriverInstalled = False) Then
            CommLostError("No FTDI Driver Installed." & vbCrLf & "Please exit the application, install the latest FTDI driver from www.ftdichip.com, and connect the hardware unit before re-starting the Snapshot application." & vbCrLf & "Driver version 2.12.24 or later is recommended.")
        Else

            ' ######## Check how many FTDI devices are connected ########

            FT_Status = FT_GetNumberOfDevices(DeviceCount, vbNullChar, FT_LIST_NUMBER_ONLY)

            ' Check if the function failed...
            If FT_Status <> FT_OK Then
                CommLostError("GetNumberOfDevices Failed")
                Exit Sub
            End If

            ' ######## Inform user if no devices connected and exit this subroutine ########

            If DeviceCount = 0 Then
                Label_NumFtdiDevices.Text = "0"
                Label_DevStatus.Text = "No FTDI Devices"

                Button_Init.Enabled = True
                Button_Run.Enabled = False
                Button_Stop.Enabled = False
                Button_Save.Enabled = False
                Button_Exit.Enabled = True
                Button_Init.Focus()
                Exit Sub
            Else
                Label_NumFtdiDevices.Text = DeviceCount.ToString    ' Display number of FTDI devices attached
            End If

            ' ######## Open the device ########

            'FT_Status = FT_OpenByDescription("FT232R USB UART", FT_OPEN_BY_DESCRIPTION, FT_Handle)
            FT_Status = FT_OpenByIndex(0, FT_Handle)

            ' Check if the function failed...
            If FT_Status <> FT_OK Then
                Label_DevStatus.Text = "No FT232R Found"
                Button_Init.Enabled = True
                Button_Run.Enabled = False
                Button_Stop.Enabled = False
                Button_Save.Enabled = False
                Button_Exit.Enabled = True
                Button_Init.Focus()
                Exit Sub
            End If

            ' ######## Update the status / buttons to show as ready  ########

            DeviceInit = True

            Label_DevStatus.Text = "Ready"

            Button_Init.Enabled = False
            Button_Run.Enabled = True
            Button_Stop.Enabled = False
            Button_Save.Enabled = False
            Button_Exit.Enabled = True
            Button_Run.Focus()




            Baudrate = 57600

            FT_Status = FT_SetBaudRate(FT_Handle, Baudrate)
            ' Check if the function failed...
            If FT_Status <> FT_OK Then
                Label_DevStatus.Text = "Error setting baud rate"
                SetErrorButtonStates()
                Exit Sub
            End If


            FT_Status = FT_SetFlowControl(FT_Handle, FT_FLOW_NONE, 0, 0)
            ' Check if the function failed...
            If FT_Status <> FT_OK Then
                Label_DevStatus.Text = "Error setting flow control"
                SetErrorButtonStates()
                Exit Sub
            End If


            FT_Status = FT_SetLatencyTimer(FT_Handle, 16)

            ' Check if the function failed...
            If FT_Status <> FT_OK Then
                Label_DevStatus.Text = "Error setting latency timer"
                SetErrorButtonStates()
                Exit Sub
            End If


            FT_Status = FT_SetTimeouts(FT_Handle, 5000, 5000)
            ' Check if the function failed...
            If FT_Status <> FT_OK Then
                Label_DevStatus.Text = "Error setting timeouts"
                SetErrorButtonStates()
                Exit Sub
            End If

            FT_Status = FT_SetDataCharacteristics(FT_Handle, 8, FT_STOP_BITS_1, FT_PARITY_NONE)

            ' Check if the function failed...
            If FT_Status <> FT_OK Then
                Label_DevStatus.Text = "Error setting data characteristics"
                SetErrorButtonStates()
                Exit Sub
            End If

            Label_BaudRate.Text = Baudrate.ToString

        End If

        Update()                                    ' Update the dialog box
        Application.DoEvents()

    End Sub

    Private Sub Button_Run_Click(sender As Object, e As EventArgs) Handles Button_Run.Click

        ' ######## Update the status / buttons to show as ready  ########
        If (DeviceInit = True) Then

            Button_Init.Enabled = False
            Button_Run.Enabled = False
            Button_Stop.Enabled = True
            Button_Save.Enabled = False
            Button_Exit.Enabled = False
            Button_Stop.Focus()
            ' Device is now initialised

            Label_DevStatus.Text = "Running"
            Running = True
            NumBytesInQueue = 0
            Update()
            Application.DoEvents()

            ' Purge
            FT_Status = FT_GetQueueStatus(FT_Handle, NumBytesInQueue)
            If ((NumBytesInQueue > 0) And (FT_Status = 0)) Then
                FT_Status = FT_Read_Bytes(FT_Handle, ClearBuffer(0), NumBytesInQueue, NumBytesRead)
            End If

            ' Send start command
            SendBuffer(0) = &H53
            FT_Status = FT_Write_Bytes(FT_Handle, SendBuffer(0), 1, NumBytesSent)

            If ((FT_Status <> FT_OK) Or (NumBytesSent <> 1)) Then
                Label_DevStatus.Text = "Error starting transfer"
                SetErrorButtonStates()
                Exit Sub
            End If


            ' Read data from device
            Buffer1Index = 0

            While (Running = True)

                FT_Status = FT_GetQueueStatus(FT_Handle, NumBytesInQueue)

                If ((NumBytesInQueue > 0) And (FT_Status = 0)) Then
                    FT_Status = FT_Read_Bytes(FT_Handle, ReceiveBuffer1(Buffer1Index), NumBytesInQueue, NumBytesRead)
                    Buffer1Index = Buffer1Index + NumBytesRead
                    Label_BytesRead.Text = Buffer1Index.ToString
                End If
                Update()
                Application.DoEvents()
            End While

            ' When stopped
            Label_BytesRead.Text = Buffer1Index.ToString
            Label_DevStatus.Text = "Stopped"

            ' Re-size array to match the number of data bytes read
            ' This allows the file to be used directly with ImageMagick without removing the empty bytes at the end
            ReDim Preserve ReceiveBuffer1(Buffer1Index - 1)

            Button_Init.Enabled = False
            Button_Run.Enabled = False
            Button_Stop.Enabled = False
            Button_Save.Enabled = True
            Button_Exit.Enabled = True
            Button_Save.Focus()

            Update()
            Application.DoEvents()

        End If
    End Sub

    Private Sub Button_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Exit.Click

        ' Code for the EXIT button
        Button_Init.Enabled = False
        Button_Run.Enabled = False
        Button_Stop.Enabled = False
        Button_Save.Enabled = False
        Button_Exit.Enabled = False
        Button_Save.Focus()

        Label_DevStatus.Text = "Closing ...."

        Update()

        ' If device was initialised, then close it before exiting. T
        If (DeviceInit = True) Then

            FT_Status = FT_Close(FT_Handle)

            If FT_Status = FT_OK Then
                Label_DevStatus.Text = "Closed"

            End If
        End If

        Sleep(1000)

        Close()
    End Sub

    Private Sub SetErrorButtonStates()
        ' Sets button enables and focus when an error has occurred
        Button_Init.Enabled = False
        Button_Run.Enabled = False
        Button_Stop.Enabled = False
        Button_Save.Enabled = False
        Button_Exit.Enabled = True
        Button_Exit.Focus()

    End Sub


    Private Sub CommLostError(ByVal messagestring As String)
        ' Displays message box and then allows user to exit
        MsgBox(messagestring)
        Button_Init.Enabled = False
        Button_Run.Enabled = False
        Button_Stop.Enabled = False
        Button_Save.Enabled = False
        Button_Exit.Enabled = True
        Button_Exit.Focus()

    End Sub



    Private Sub SaveSetting_Click(sender As Object, e As EventArgs) Handles Button_Save.Click
        ' Brings up the save-file dialog and allows user to save file with .bgra extension

        Sleep(100)

        SaveFileDialog1.Filter = "All files (All files (*.*)|*.*"
        SaveFileDialog1.FilterIndex = 1
        If SaveFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
            filepath = SaveFileDialog1.FileName
            filepath = filepath & ".argb"
            My.Computer.FileSystem.WriteAllBytes(filepath, ReceiveBuffer1, False)

        End If



    End Sub


    Private Sub Button_Stop_Click(sender As Object, e As EventArgs) Handles Button_Stop.Click

        Label_DevStatus.Text = "Stopped"
        Running = False

        Update()
        Application.DoEvents()
    End Sub


End Class

